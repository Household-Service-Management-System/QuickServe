import { Link } from "react-router-dom";
import "./AdminDashboard.css";

export default function AdminDashboard() {
  return (
    <div className="layout">

      {/* Sidebar */}
      <aside className="sidebar">
        <h2 className="logo">QuickServe</h2>
        <p className="panel-text">Admin Panel</p>

        <nav className="menu">
          <Link to="/admin" className="menu-item active">Dashboard</Link>
          <Link to="/admin/customer" className="menu-item">Customer</Link>
          <Link to="/admin/serviceProvider" className="menu-item">Service Provider</Link>
          <Link to="/admin/pendingRequest" className="menu-item">Pending Request</Link>
          <Link to="/admin/paymentList" className="menu-item">Payment</Link>
          <Link to="/admin/setting" className="menu-item">Setting</Link>
        </nav>

  <Link to="/admin/logout">
  <button className="logout-btn">Logout</button>
</Link>

      </aside>

      {/* Main Content */}
      <main className="content">
        <h1 className="page-title">Dashboard Overview</h1>

        <input
          type="text"
          className="search-bar"
          placeholder="Search..."
        />

        <div className="stats-grid">
          <div className="stat-box">
            <h3>Total Service Providers</h3>
            <p className="stat-value">25</p>
          </div>

          <div className="stat-box">
            <h3>Total Revenue</h3>
            <p className="stat-value">$12,500</p>
          </div>

          <div className="stat-box">
            <h3>Total Customers</h3>
            <p className="stat-value">250</p>
          </div>

          <div className="stat-box">
            <h3>Pending Requests</h3>
            <p className="stat-value">8</p>
          </div>
        </div>
      </main>
    </div>
  );
}
